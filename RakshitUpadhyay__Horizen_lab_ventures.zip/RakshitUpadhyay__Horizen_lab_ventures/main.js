window.onload = function()
{

    var logo = document.querySelector('#section3 #bg1');
        setTimeout(function() {
            console.log("1");
            logo.style.opacity = '1' ;
        }, 1000);  
    


    var navbar = document.getElementById('navbar');
    if (window.scrollY >= 10) {
         
        navbar.style.opacity = '0.2' ;
        navbar.style.backdropFilter = 'blur(0px)' ;

      } else {
        navbar.style.opacity = '1' ;
      }

    var element1 =  document.querySelector('#section4 #div1 #div11');
    var element2 =  document.querySelector('#section4 #div1 #div12');
    var element3 =  document.querySelector('#section4 #div1 #div12 img');

    element1.style.transition = "all 3s ease-in-out";
    element2.style.transition = 'all 3s ease-in-out';
    element3.style.transition = 'all 3s ease-in-out';
 
    console.log("hello");
    window.addEventListener('scroll', function() {

      if (window.scrollY >= 800  && window.scrollY <= 1900  ) 
      {
        element1.style.width = '25rem';
        element1.style.height = '25rem' ;
        element2.style.width = '19rem';
        element2.style.height = '19rem' ;
        element2.style.marginTop = '3rem';
        element2.style.marginLeft = '3rem' ;
        element3.style.marginTop = '3rem';
        element3.style.marginLeft = '3rem' ;
        element3.style.padding = '1rem' ;
        element1.style.top = '7rem';
        element1.style.left = '7rem' ;
      } else {
        element1.style.width = '10rem';
        element1.style.height = '10rem' ;
        element2.style.width = '10rem';
        element2.style.height = '10rem' ;
        element2.style.marginTop = '0rem';
        element2.style.marginLeft = '0rem' ;
        element3.style.marginTop = '0rem';
        element3.style.marginLeft = '0rem' ;
        element3.style.padding = '0rem' ;
        element1.style.top = '15rem';
        element1.style.left = '12rem' ;
      }
    });


    var element4 =  document.querySelector('#dummy1');
    var element5 =  document.querySelector('#dummy2');
    var element6 =  document.querySelector('#div2-img2');

    window.addEventListener('scroll', function() {
    
    element4.style.transition = "all 2s ease-in-out";
    element5.style.transition = 'all 2s ease-in-out';
    element6.style.transition = 'all 2s ease-in-out';

      if (window.scrollY >=  1600 && window.scrollY <=  2500) {
        element4.style.margin = '3rem 3rem -3rem -3rem';
        element5.style.margin = '-3rem -3rem 3rem 3rem' ;
      } else {
        
        element4.style.margin = '0rem 0rem 0rem 0rem';
        element5.style.margin = '0rem 0rem 0rem 0rem' ;
         
      }
    });

    var element7 =  document.querySelector('#s6-div11');
    var element8 =  document.querySelector('#s6-div1-img1');
    var element9 =  document.querySelector('#s6-div1-arrow1');
    var element10 =  document.querySelector('#s6-div1-arrow2');

    window.addEventListener('scroll', function() {
    
    element7.style.transition = "all 1s ease-in-out";
    element8.style.transition = 'all 1s ease-in-out';
    element9.style.transition = "all 1s ease-in-out 1s";
    element10.style.transition = 'all 1s ease-in-out 1s';
     

      if (window.scrollY >= 2400 && window.scrollY <= 3200 ) {
        element7.style.height = '12rem';
        element7.style.width = '12rem';
        element8.style.padding = '3rem';
        element8.style.padding = '3rem';
        element9.style.opacity = '1' ;
        element10.style.opacity = '1' ;
        element9.style.marginLeft='8rem' ;
        element10.style.marginLeft='24rem' ;
       

      } else {
        
        element7.style.height = '8rem';
        element7.style.width = '8rem';
        element8.style.padding = '1rem';
        element8.style.padding = '1rem';
        element9.style.opacity = '0' ;
        element10.style.opacity = '0' ;
        element9.style.marginLeft='4rem' ;
        element10.style.marginLeft='20rem' ;
         
      }

    });


      var element11 =  document.getElementById('s7-div2-img2');
      var element12 =  document.getElementById('s7-div2-img4');
      var element13 =  document.getElementById('s7-div2-img1');
      var element14 =  document.getElementById('s7-div2-img5');
      
      
      window.addEventListener('scroll', function() {
      
      element11.style.transition = "all 1s ease-in-out";
      element12.style.transition = 'all 1s ease-in-out';
      element13.style.transition = "all 1s ease-in-out 1s";
      element14.style.transition = 'all 1s ease-in-out 1s';
    
    
  
        if (window.scrollY >= 3350 && window.scrollY <= 4000 ) {
          console.log("all ok");
          element11.style.marginLeft = '1rem';
          element12.style.marginLeft = '14rem';
          element13.style.opacity = '1';
          element14.style.opacity = '1';
          element13.style.marginTop = '0rem';
          element14.style.marginTop= '4rem';
           
        } else {
          
          element11.style.marginLeft = '4rem';
          element12.style.marginLeft = '11rem';
          element13.style.opacity = '0';
          element14.style.opacity = '0';
          element13.style.marginTop = '3rem';
          element14.style.marginTop = '1rem';
        }  

    });

}
  

 